module.exports = (url) => {
    try {
        const newUrl = new URL(url);
        return false
    } catch(err) {
        return true
    }
}