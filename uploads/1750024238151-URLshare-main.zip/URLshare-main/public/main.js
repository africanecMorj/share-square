$(document).ready(function() {
    const $menuIcon = $('#menuIcon');
    const $popupMenu = $('#popupMenu');
    const $overlay = $('#overlay');
    const $menuItems = $('.popup-menu-item');
    const $addLinkContent = $('.add-link-content');
    const $codeInput = $('.code-input');
    const $codeFrame = $('.code-frame');
    const $musicBtn = $('#musicBtn');
    const $musicContainer = $('#musicContainer');
    const $musicButtons = $('.music-btn');
    const $codeSubmitBtn = $('.code-submit-btn');
    let currentAudio = null;
    let currentUser = null;
    let currentUserPass = null;
    let userHistory = null;
    let logVerif = false;

    function hideAllForms() {
        $('#urlForm, #loginForm, #deleteUrlForm, #registerForm, #historyForm').hide();
        $('#overlay').removeClass('form-active');
    }
    hideAllForms();

    function updateUI() {
        if (currentUser != null) {
            $('#logoutBtn').show();
            $('#loginBtn').hide();
            $('#registerBtn').hide();
            $('#historyBtn').show();
        } else if(currentUser == null){
            $('#logoutBtn').hide();
            $('#loginBtn').show();
            $('#registerBtn').show();
            $('#historyBtn').hide();
        }
        hideAllForms();
    }

    const Login = localStorage.getItem('login');
    const Password = localStorage.getItem('password');
    console.log(Password, Login)
        axios.post('/signIn', {login: Login, password: Password})
        .then(res => {
            if(res.data == `Incorrect login` || res.data ==`Incorrect password`){
                currentUser = null;
                currentUserPass = null;
                userHistory = null;
                $('#logoutBtn').hide();
                $('#loginBtn').show();
                $('#registerBtn').show();
                $('#historyBtn').hide();
                logVerif = false;
                hideAllForms();
                

            } else {
                currentUserPass = Password;
                currentUser = Login;
                userHistory = res.data.history;
                logVerif = true;
                $('#logoutBtn').show();
                $('#loginBtn').hide();
                $('#registerBtn').hide();
                $('#historyBtn').show();
                hideAllForms();
            }
        })
    

    $menuIcon.on('click', function() {
        $(this).toggleClass('active');
        $popupMenu.toggleClass('active');
        $overlay.toggleClass('active');
    });

    $overlay.on('click', function() {
        hideAllForms();
    });

    $menuItems.on('click', function() {
        if (!$(this).is('#musicBtn') && !$(this).is('#registerBtn') && !$(this).is('#loginBtn') && !$(this).is('#logoutBtn')) {
            $menuIcon.removeClass('active');
            $popupMenu.removeClass('active');
            $overlay.removeClass('active');
            hideAllForms();
        }
    });

    $addLinkContent.on('click', function() {
        $(this).css('transform', 'translateY(-5px) scale(0.95)');
        setTimeout(() => {
            $(this).css('transform', 'translateY(-5px) scale(1)');
        }, 150);
        hideAllForms();
        $('#urlForm').show();
        $('#overlay').addClass('form-active');
    });

    function fetchUrl(code) {
        axios.get(`/getUrl/${code}`)
            .then(function(response) {
                window.open(response.data, '_blank');
                $codeInput.val('');
            })
            .catch(function(error) {
                alert(error.response?.data || 'Помилка при отриманні URL');
            });
    }

    $codeInput.on('focus', function() {
        $codeFrame.css('transform', 'scale(1.05)');
    });

    $codeInput.on('blur', function() {
        $codeFrame.css('transform', 'scale(1)');
    });

    $codeSubmitBtn.on('click', function() {
        const code = $codeInput.val().trim();
        if (!code) {
            alert('Введіть код');
            return;
        }
        fetchUrl(code);
    });

    $codeInput.on('keypress', function(e) {
        if (e.which === 13) {
            const code = $(this).val().trim();
            if (!code) {
                alert('Введіть код');
                return;
            }
            fetchUrl(code);
        }
    });

    $(document).on('keydown', function(e) {
        if (e.key === 'Escape') {
            $menuIcon.removeClass('active');
            $popupMenu.removeClass('active');
            hideAllForms();
        }
    });

    $musicBtn.on('click', function(e) {
        e.stopPropagation();
        $musicContainer.toggleClass('active');
    });

    $musicButtons.each(function(index) {
        const audio = $(this).siblings('audio')[0];
        const volumeSlider = $(this).siblings('.volume-slider');

        audio.volume = volumeSlider.val() / 100;

        $(this).on('click', function(e) {
            e.stopPropagation();
            if (currentAudio && currentAudio !== audio) {
                currentAudio.pause();
                currentAudio.currentTime = 0;
            }
            if (currentAudio === audio) {
                currentAudio.pause();
                currentAudio = null;
            } else {
                currentAudio = audio;
                audio.volume = volumeSlider.val() / 100;
                audio.play();
            }
        });

        volumeSlider.on('input', function() {
            audio.volume = this.value / 100;
        });
    });

    $('#urlForm').on('submit', function(e) {
        e.preventDefault();
        const url = $('#urlInput').val().trim();
        if (!url) {
            alert('Введіть URL');
            return;
        }
        if(logVerif == false){
            axios.post('/sendUrl', { URL: url, login: false , password: false })
            .then(function(response) {
                alert(`URL скорочено! Ваш код: ${response.data}`);
                hideAllForms();
                $('#urlInput').val('');
            })
            .catch(function(error) {
                alert(error.response?.data || 'Помилка при відправці URL');
                hideAllForms();
            });
        } else {
            axios.post('/sendUrl', { URL: url, login: currentUser , password: currentUserPass })
            .then(function(response) {
                alert(`URL скорочено! Ваш код: ${response.data}`);
                hideAllForms();
                $('#urlInput').val('');
            })
            .catch(function(error) {
                alert(error.response?.data || 'Помилка при відправці URL');
                hideAllForms();
            });
        }
            
    });

    $('#loginBtn').on('click', function(e) {
        e.stopPropagation();
        hideAllForms();
        $('#loginForm').show();
        $('#overlay').addClass('form-active');
    });

    $('#deleteBtn').on('click', function(e) {
        e.stopPropagation();
        hideAllForms();
        $('#deleteUrlForm').show();
        $('#overlay').addClass('form-active');
    });

    $('#historyBtn').on('click',async function(e) {
        e.stopPropagation();
        hideAllForms();
        $('#historyForm').show();
        $('#overlay').addClass('form-active');
        $(`.historyContainer`).empty()
        userHistory.forEach((i) => {
                $(`.historyContainer`).append(`
                <div>
                    <p>${i.url}</p>
                    <p>${i.code}</p>
                </div>            
            `);
        });
    });


    $('#loginForm').on('submit', function(e) {
        e.preventDefault();
        const login = $('#signInLogin').val().trim();
        const password = $('#signInPassword').val();

        if (!login || !password) {
            alert('Будь ласка, введіть логін і пароль');
            return;
        }

        axios.post('/signIn', { login: login, password: password })
            .then(res => {
                if(res.data == `Incorrect password`){
                    alert(`Такого пароля не існує`);
                    $('#signInLogin, #signInPassword').val('');
                }else if(res.data == `Login is occupied`) {
                    alert(`Такого логіна не існує`);
                    $('#signInLogin, #signInPassword').val('');
                }else{
                    alert(`Ви усішно увійшли в аккаунт`);
                    localStorage.setItem('login', login);
                    localStorage.setItem('password', password);
                    currentUser = login;
                    currentUserPass = password;
                    logVerif = true;
                     $('#logoutBtn').show();
                    $('#loginBtn').hide();
                    $('#registerBtn').hide();
                    $('#historyBtn').show();
                    
                    hideAllForms();
                    $('#signInLogin, #signInPassword').val('');
                }
            })
    });

    $('#logoutBtn').on('click', function() {
        localStorage.removeItem('login');
        localStorage.removeItem('password');
        currentUser = null;
        currentUserPass = null;
        logVerif = false;
        $('#logoutBtn').hide();
        $('#loginBtn').show();
        $('#registerBtn').show();
        $('#historyBtn').hide();
        hideAllForms();
    });

    $('#deleteUrlForm').on('submit', function(e) {
        e.preventDefault();
        const login = $(`#deleteLogin`).val();
        const password = $(`#deletePassword`).val();
        const code = $('#deleteCode').val().trim();
        
        if (!login || !password) {
            axios.delete(`/deleteUrl/${code}/false/false`)
            .then(res => {
                if(res.data == `This code or login doesn't exist`){
                    alert(`Цього коду не існує`);                
                    $('#deleteCode, #deleteLogin, #deletePassword').val('');
                
                }else if(res.data == `Succesfully deleted`){
                    alert(`Успішно видалено`);
                    $('#deleteCode, #deleteLogin, #deletePassword').val('');
                    hideAllForms();
                }

                
            })

        }

            axios.delete(`/deleteUrl/${code}/${login}/${password}`)
            .then(res => {
                console.log(res)
                if(res.data == `This code or login doesn't exist`){
                    alert(`Цього коду не існує`);                
                    $('#deleteCode, #deleteLogin, #deletePassword').val('');
                
                }else if(res.data == `Succesfully deleted`){
                    alert(`Успішно видалено`);
                    hideAllForms();
                }

                
            })
        
    });

    $('#urlForm button[type="button"]').on('click', function() {
        hideAllForms();
    });

    $('#loginForm button[type="button"]').on('click', function() {
        hideAllForms();
    });

    $('#registerForm button[type="button"]').on('click', function() {
        hideAllForms();
    });

    $('#deleteUrlForm button[type="button"]').on('click', function() {
        hideAllForms();
    });

    $('#historyForm button[type="button"]').on('click', function() {
        hideAllForms();
    });

    $('#registerBtn').on('click', function(e) {
        e.stopPropagation();
        hideAllForms();
        $('#registerForm').show();
        $('#overlay').addClass('form-active');
    });

    $('#registerForm').on('submit', function(e) {
        e.preventDefault();
        const login = $('#regLogin').val().trim();
        const password = $('#regPassword').val();

        if (!login || !password) {
            alert('Будь ласка, введіть логін і пароль');
            return;
        }

        axios.post('/registration', { login: login, password: password })
            .then(function(response) {
                alert(response.data);
                if (response.data == `Succesfully regisrated`) {
                    localStorage.setItem('login', login);
                    localStorage.setItem('password', password);
                    currentUser = login;
                    currentUserPass = password;
                    logVerif = true;
                    userHistory = response.data.history;
                    $('#logoutBtn').show();
                    $('#loginBtn').hide();
                    $('#registerBtn').hide();
                    $('#historyBtn').show();
                }
                hideAllForms();
                $('#regLogin, #regPassword').val('');
            })
            
    });
});