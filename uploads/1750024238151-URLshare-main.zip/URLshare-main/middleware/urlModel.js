const mongoose = require(`mongoose`);

const urlModel = new mongoose.Schema ({
    code: String,
    url: String,
    login:String,
});
const URL = mongoose.model(`urlCollection`, urlModel);

module.exports = URL;
