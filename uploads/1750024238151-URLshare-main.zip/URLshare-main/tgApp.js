module.exports = () => {
    const path = require(`path`);
    const mongoose = require(`mongoose`);
    const bcrypt = require(`bcrypt`);
    const tgBot = require(`node-telegram-bot-api`);
    const recogUrl = require(path.join(__dirname, `middleware/recogUrl`));
    const generateNum = require(path.join(__dirname, `middleware/generateNum`));
    const UrlModel = require(path.join(__dirname, `/middleware/urlModel`));
    const LoginModel = require(path.join(__dirname, `/middleware/loginModel`));
    const PassModel = require(path.join(__dirname, `middleware/PassModel`));
    require(`dotenv`).config();


    let limitedUserTg = [];
    let waitingForSend = {};
    let waitingForGet = {};

    const bot = new tgBot(process.env.TG_URI, {polling:true});

    bot.onText(/\/menu/, (msg) => {
    const chatId = msg.chat.id;
    bot.sendMessage(chatId, 'Оберіть дію:', {
        reply_markup: {
        inline_keyboard: [
            [
            { text: 'Надіслати посилання', callback_data: 'sendUrl' },
            { text: 'Отримати посилання', callback_data: 'getUrl' }
            ],
        ]
        }
    });
    });

    bot.on('callback_query', (callbackQuery) => {
    const data = callbackQuery.data;
    const chatId = callbackQuery.message.chat.id;

    if (data === 'sendUrl') {
        bot.sendMessage(chatId, 'Надішли своє посилання');
        waitingForSend[chatId] = true;

    } else if (data === 'getUrl') {
        bot.sendMessage(chatId, `Надішли свій код`);
        waitingForGet[chatId] = true;
    } 

    
    bot.answerCallbackQuery(callbackQuery.id);
    });

    bot.on('message', async(msg) => {
    const chatId = msg.chat.id;
    const text = msg.text;

    if (text.startsWith('/')) return;

    if (waitingForSend[chatId]) {
        const verif = recogUrl(text);

        switch (true) {
            case limitedUserTg.includes(chatId):
                bot.sendMessage(chatId, `Ви перевищили ліміт.Очікуйте п'ятнадцять хвилин`);
                break;
            case verif:
                bot.sendMessage(chatId, `Не дійсне посилання`);
                break;
            case text.length > 170:
                bot.sendMessage(chatId, `Занадто великий обсяг посилання`);
                break;
            case verif == false:
                const code = generateNum();
                let urlModel = UrlModel({
                    code:`${code}`,
                    url:`${text}`,
                    login:false
                });
                urlModel.save();
                let timerMg = setTimeout(async() => {
                    await UrlModel.deleteOne({code:`${code}`, url:`${text}`});
                }, 604800000);

                limitedUserTg.push(chatId);
                let timerTg = setTimeout(() => {
                    limitedUserTg = limitedUserTg.filter((e) => e != chatId);
                }, 600000);

                bot.sendMessage(chatId, code);
                
        };
        
        delete waitingForSend[chatId];
    } else if(waitingForGet[chatId]){
        const reqUrl = await UrlModel.findOne({code:`${text}`});
        if(reqUrl == null){
            bot.sendMessage(chatId, `Цього коду не існує`);
        }else{
            bot.sendMessage(chatId, reqUrl.url);
        }
        delete waitingForGet[chatId];
    }
    });

}