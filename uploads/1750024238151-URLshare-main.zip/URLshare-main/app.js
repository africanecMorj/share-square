const express = require(`express`);
const app = express();
const PORT = 3000;
const path = require(`path`);
const bodyParser = require(`body-parser`);
const mongoose = require(`mongoose`);
const bcrypt = require(`bcrypt`);
const tgBot = require(`node-telegram-bot-api`);
const recogUrl = require(path.join(__dirname, `middleware/recogUrl`));
const generateNum = require(path.join(__dirname, `middleware/generateNum`));
const UrlModel = require(path.join(__dirname, `/middleware/urlModel`));
const LoginModel = require(path.join(__dirname, `/middleware/loginModel`));
const PassModel = require(path.join(__dirname, `middleware/PassModel`));
const tgApp = require(path.join(__dirname, `/tgApp`));
require(`dotenv`).config();

app.use(express.static(path.join(__dirname, `public`)));
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({extended:true}));


mongoose.connect(process.env.MONGO_URI)
.then(() => {
    console.log(`Connected to mongoDb`)
})
.catch((err) => {
    console.log(`Cannot connect to mongoDb`, err)
});
tgApp();

let limitedUser = [];

app.post(`/sendUrl`, async(req, res) => {
    const ip = req.headers['x-forwarded-for'] || req.connection.remoteAddress;
    const verif = recogUrl(req.body.URL);
    const {URL, login, password} = req.body;

    switch (true) {
        case limitedUser.includes(ip):
            res.send(`You have exceeded the limit. Await 5 minute`);
            break;
        case verif:
            res.send(`Incorrect url`);
            break;
        case req.body.URL.length > 170:
            res.send(`Too long url`);
            break;
        case verif == false:
            if(login == false){
                const {URL, login} = req.body;
                const code = generateNum();
                let urlModel = UrlModel({
                    code:`${code}`,
                    url:`${URL}`,
                    login:`${login}`
                });
                urlModel.save();
                let timerMg = setTimeout(async() => {
                    await UrlModel.deleteOne({code:`${code}`, url:`${URL}`});
                }, 604800000);

                limitedUser.push(ip);
                let timerIp = setTimeout(() => {
                limitedUser = limitedUser.filter((e) => e != ip);
                }, 300000);

                res.json(code);
                } else {
                    const match = await LoginModel.findOne({login:login});
                    if(match == null){
                        res.send(`This login doesn't exist`);
                    } else {

                        const saltedPass = `${password}`+`${match.salt}`;
                        const hashTable = await PassModel.find();
                        
                        for(let i =0; i<hashTable.length; i++) {
                            result = await bcrypt.compare(saltedPass, hashTable[i].hash);
                            if(result == true){
                                break;
                            }
                        }

                    if (result == true){
                        const code = generateNum();
                        let urlModel = UrlModel({
                            code:`${code}`,
                            url:`${URL}`,
                            login:`${login}`
                        });
                        urlModel.save();
                        let timerMg = setTimeout(async() => {
                            await UrlModel.deleteOne({code:`${code}`, url:`${URL}`});
                        }, 604800000);

                        limitedUser.push(ip);
                        let timerIp = setTimeout(() => {
                        limitedUser = limitedUser.filter((e) => e != ip);
                        }, 300000);

                        res.json(code);

                    } else{
                        res.send(`Incorrect password`);
                    };
            
            }
        }
    };
    
});

app.get(`/getUrl/:code`, async(req, res) => {
    const code = req.params.code;
    const reqUrl = await UrlModel.findOne({code:`${code}`});
    if(reqUrl == null){
        res.send(`This code doesn't exist`);
    }else{
        res.json(reqUrl.url);
    }
});

app.delete(`/deleteUrl/:code/:login/:password`, async(req, res) => {
    const {code, login, password} = req.params;
    if(login == `false`){
        const dltRep = await UrlModel.deleteOne({code:`${code}`});
        if(dltRep.deletedCount == 0){
            res.send(`This code doesn't exist`);
        } else {
            res.send(`Succesfully deleted`);
        };
    } else {
        const match = await UrlModel.findOne({code:`${code}`, login:`${login}`});
        if(match == null){
            res.send(`This code or login doesn't exist`);
        } else {
            const loginTable = await LoginModel.findOne({login:login});

            const saltedPass = `${password}`+`${loginTable.salt}`;
            const hashTable = await PassModel.find();
            
            for(let i =0; i<hashTable.length; i++) {
                result = await bcrypt.compare(saltedPass, hashTable[i].hash);
                if(result == true){
                    break;
                }
            }

            if (result == true){
                const dltRep = await UrlModel.deleteOne({code:`${code}`, login:`${login}`});
                res.send(`Succesfully deleted`);

            } else{
                res.send(`Incorrect password`);
            };
    
        }
    }
});

app.post(`/registration`, async(req, res) => {
    const {password, login} = req.body;
    const matches = await LoginModel.find({login:login});
    if(matches.length == 0) {
        const salt = Math.random().toString(36).substring(2, 12 + 2);
        const saltedPass = `${password}` + `${salt}`;
        bcrypt.hash(saltedPass, 10, (err, hash) => {
            const userPass = PassModel({
                hash:hash
            });
            userPass.save();
        });

        
        const newUser = LoginModel({
            login:`${login}`,
            salt:`${salt}`,
        });

        newUser.save();

        res.send(`Succesfully regisrated`);
    } else {
        res.send(`Login is occupied`);
    }
    
});

app.post(`/signIn/`, async(req, res) => {
    const {password, login} = req.body;
    const match = await LoginModel.findOne({login:login});
    let result;
    if(match != null) {
        const saltedPass = `${password}`+`${match.salt}`;
        const hashTable = await PassModel.find();
        
        for(let i =0; i<hashTable.length; i++) {
            result = await bcrypt.compare(saltedPass, hashTable[i].hash);
            if(result == true){
                break;
            }
        }

        if (result == true){
            const userHistory = await UrlModel.find({login:login});
            res.json({mesage:`Succesfully signed in`, history:userHistory });
        } else{
            res.send(`Incorrect password`);
        };
    
    } else {
        res.send(`Incorrect login`);
    }
})

app.get(`/`, (req, res) => {
    res.sendFile(path.join(__dirname, `/public/index.html`))
});

app.listen(PORT, () => {
    console.log(`http://localhost:3000`);
});

