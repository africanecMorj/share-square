$(document).ready(function() {
    $('#registerBtn').on('click', function(e) {
        e.stopPropagation();
        $('#registerForm').show();
    });

    $('#registerForm').on('submit', function(e) {
        e.preventDefault();
        const login = $('#regLogin').val();
        const password = $('#regPassword').val();

        axios.post('/registration', { login: login, password: password })
            .then(function(response) {
                alert(response.data);
                $('#registerForm').hide();
                $('#regLogin, #regPassword').val('');
            })
            .catch(function(error) {
                alert('Помилка при реєстрації');
            });
    });

    $(document).on('keydown', function(e) {
        if (e.key === 'Escape') {
            $('#registerForm').hide();
        }
    });
});